import edu.princeton.cs.algs4.StdOut;

public class HelloGoodbye {
    public static void main(String[] args) {
    //     System.out.println("Hello "+args[0]+" and "+args[1]+".");
    //     System.out.println("Goodbye "+args[1]+" and "+args[0]+".");
    StdOut.println("Hello "+args[0]+" and "+args[1]+".");
    StdOut.println("Goodbye "+args[1]+" and "+args[0]+".");
    }
}
